-- Compiler directive converting strings to Unicode
{-# LANGUAGE OverloadedStrings #-}
module Main where

import Web.Scotty


main :: IO ()
main = do -- IO Monad
    putStrLn "Starting Server at 4711 ..."
    scotty 4711 $ do -- bruger en ScottyM monad
        get "/hello" $ do -- ActionM monad
            text "Hello World!"
        


-- do indsætter automatisk >>= mellem expressions.
-- Den håndterer altså selv at passere Monaden rundt